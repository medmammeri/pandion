# setup file used to be the place to make installation scripts and code
# but now this is viewed as a security risk
# so code is "transferred" to other configuration files
from setuptools import setup

if __name__ == "__main__":
	setup()
